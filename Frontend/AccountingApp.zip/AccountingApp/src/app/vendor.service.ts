import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import {Vendor} from './vendor'
@Injectable({
  providedIn: 'root'
})
export class VendorService {
  private baseURL = "http://localhost:8080/details";
  constructor( private httpClient: HttpClient) { }


public httpOptions = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin':'*',
      'Authorization':'authkey'
    })
  }
  getVendor(): Observable<Vendor[]>{
    return this.httpClient.get<Vendor[]>(`${this.baseURL}`);
  }

  createVendor(vendor: Vendor): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, vendor);
  }
  
}
