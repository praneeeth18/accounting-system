export interface Vendor {
    
    vendorName: string;
    vendorEmail: string;
}