export class Vendor {
    vendorId!:number;
    vendorName!: string ;
    vendorEmail!: string;
}