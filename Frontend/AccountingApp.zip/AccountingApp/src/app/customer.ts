export class Customer {
    customerId!:number;
    customerName!: string ;
    customerEmail!: string;
    customerAddress!:string;
}
