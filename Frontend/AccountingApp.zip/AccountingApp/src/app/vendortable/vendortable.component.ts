import { Component, OnInit } from '@angular/core';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendortable',
  templateUrl: './vendortable.component.html',
  styleUrl: './vendortable.component.css'
})
export class VendortableComponent implements OnInit {
  constructor( private vendorService :VendorService ){}

  public vendorList:any;
    ngOnInit(): void { 
      this.getvendorDetails();
    }
  getvendorDetails() {
      this.vendorService.getVendor().subscribe(
        data=>{
          this.vendorList=data;
          console.log(data);
        },
        (error)=>console.log(error)
      )
  }
 
}
