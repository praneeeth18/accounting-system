import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
declare function sidebar() : any;


@Component({
  selector: 'app-customer-table',
  templateUrl: './customer-table.component.html',
  styleUrl: './customer-table.component.css'
})
export class CustomerTableComponent {
 
  public customertableForm !: FormGroup;
  customer: any;
  constructor(private formBuilder : FormBuilder, private http: HttpClient, private router: Router) {}
 
 
  ngOnInit(): void {
    this.customertableForm = this.formBuilder.group({
      customername: [''],
      
      address:[''],
      email: ['']
      
    })
 
    sidebar();
 
    this.getCustomerDetails();
  }
 
 
  getCustomerDetails() {
 
    return this.http.get<any>("http://localhost:3000/customer").subscribe(data=>{
      console.log('customer',data);
      this.customer = data;
    })
   
  }
 
 
}