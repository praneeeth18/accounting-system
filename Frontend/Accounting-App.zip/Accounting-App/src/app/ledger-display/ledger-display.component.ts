import { Component } from '@angular/core';
import { LedgerService } from '../ledger.service';
import { Ledger } from '../ledger';

@Component({
  selector: 'app-ledger-display',
  templateUrl: './ledger-display.component.html',
  styleUrls: ['./ledger-display.component.css']
})
export class LedgerDisplayComponent {


  ledger:any;
  constructor(
    private ledgerService:LedgerService
   ){}

   
   ngOnInit(): void {
      this.get();
  }

  get(){
    this.ledgerService.displayledger().subscribe(data=>
      {
        
        this.ledger=data; 
        console.log(this.ledger);

      });
  }
}
