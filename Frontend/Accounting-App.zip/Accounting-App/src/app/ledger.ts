export class Ledger {
    entryid:number | undefined;
    transactiondate!: Date;
    description:String | undefined;
    transactiontype:String | undefined;
    amount:number | undefined;
    balance:number | undefined;
}
