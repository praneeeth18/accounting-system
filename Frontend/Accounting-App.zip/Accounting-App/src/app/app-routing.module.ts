import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LedgerEntryComponent } from './ledger-entry/ledger-entry.component';
import { VendorComponent } from './vendor/vendor.component';
import { LedgerDisplayComponent } from './ledger-display/ledger-display.component';

const routes: Routes = [
  { path: '', redirectTo: '/ledger-entry', pathMatch: 'full' },
  { path: 'ledger-entry', component: LedgerEntryComponent },
  { path: 'ledger-display', component:LedgerDisplayComponent},
  { path: 'vendor', component:VendorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
