import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

declare function sidebar() : any;

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

  ngOnInit(){

    sidebar();
  }
}
