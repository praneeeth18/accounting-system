import { Component } from '@angular/core';

@Component({
  selector: 'app-sales-table',
  standalone: true,
  imports: [],
  templateUrl: './sales-table.component.html',
  styleUrl: './sales-table.component.css'
})
export class SalesTableComponent {

}
