import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';

declare function sidebar() : any;

@Component({
  selector: 'app-sales-table',
  standalone: true,
  imports: [RouterLink, DashboardComponent],
  templateUrl: './sales-table.component.html',
  styleUrl: './sales-table.component.css'
})
export class SalesTableComponent {

  ngOnInit(){

    sidebar();
  }
  
}
