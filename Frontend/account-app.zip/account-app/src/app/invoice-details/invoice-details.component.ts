import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';


declare function sidebar() : any;
@Component({
  selector: 'app-invoice-details',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, FormsModule, DashboardComponent],
  templateUrl: './invoice-details.component.html',
  styleUrl: './invoice-details.component.css'
})
export class InvoiceDetailsComponent implements OnInit{

  public invoiceForm !: FormGroup;
  constructor(private formBuilder : FormBuilder, private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.invoiceForm = this.formBuilder.group({
      customername: ['', Validators.required],
      invoicenumber:['', Validators.required],
      date:['', Validators.required],
      proddesc: ['', Validators.required],
      quantity: ['', Validators.required],
      price:['', Validators.required],
      status:['', Validators.required]
    })

    sidebar();
  }

  invoice() {
    this.http.post<any>("http://localhost:3000/invoice",this.invoiceForm.value)
    .subscribe(res=>{
      alert("Invoice Generated Successfully");
      this.invoiceForm.reset();
      this.router.navigate(['sales-table']);

    }, err=>{
      alert("Something went wrong");
    }
    )
  }

}
