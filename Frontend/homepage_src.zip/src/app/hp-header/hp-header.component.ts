import { Component } from '@angular/core';

@Component({
  selector: 'app-hp-header',
  templateUrl: './hp-header.component.html',
  styleUrl: './hp-header.component.css'
})
export class HpHeaderComponent {

}
