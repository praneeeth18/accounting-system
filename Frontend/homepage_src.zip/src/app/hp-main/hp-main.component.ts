import { Component } from '@angular/core';

@Component({
  selector: 'app-hp-main',
  templateUrl: './hp-main.component.html',
  styleUrl: './hp-main.component.css'
})
export class HpMainComponent {

}
