import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HpHeaderComponent } from './hp-header/hp-header.component';
import { HpFooterComponent } from './hp-footer/hp-footer.component';
import { HpMainComponent } from './hp-main/hp-main.component';

@NgModule({
  declarations: [
    AppComponent,
    HpHeaderComponent,
    HpFooterComponent,
    HpMainComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
