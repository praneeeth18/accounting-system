import { Component } from '@angular/core';

@Component({
  selector: 'app-hp-footer',
  templateUrl: './hp-footer.component.html',
  styleUrl: './hp-footer.component.css'
})
export class HpFooterComponent {

}
