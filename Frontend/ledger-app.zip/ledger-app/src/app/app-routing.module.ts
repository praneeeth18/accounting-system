// app-routing.module.ts
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LedgerTableComponent } from './ledger-table/ledger-table.component';
import { LedgerEntryComponent } from './ledger-entry/ledger-entry.component';

const routes: Routes = [
  { path: '', redirectTo: '/ledger', pathMatch: 'full' },
  { path: 'ledger', component: LedgerTableComponent }, // Define a route for 'ledger'
  { path: 'ledger-table', component: LedgerTableComponent },
  { path: 'ledger-entry', component: LedgerEntryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
