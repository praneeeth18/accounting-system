import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ledger-entry',
  templateUrl: './ledger-entry.component.html',
  styleUrls: ['./ledger-entry.component.css']
})
export class LedgerEntryComponent {
goToLedgerTablePage: any;

  constructor(private router: Router) {}

  onSubmit() {
    
  }

  onAddEntry() {
    // Navigate to the ledger table page
    this.router.navigate(['/ledger-table']);
  }
  goToLedgerEntryPage() {
    this.router.navigate(['/ledger-entry']);
  }
}
