// ledger-table.component.ts
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ledger-table',
  templateUrl: './ledger-table.component.html',
  styleUrls: ['./ledger-table.component.css']
})
export class LedgerTableComponent {
  constructor(private router: Router) {}

  goToLedgerEntryPage() {
    this.router.navigate(['/ledger-entry']);
  }
}
