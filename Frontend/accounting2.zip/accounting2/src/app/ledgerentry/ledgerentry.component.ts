import { Component } from '@angular/core';

@Component({
  selector: 'app-ledgerentry',
  templateUrl: './ledgerentry.component.html',
  styleUrl: './ledgerentry.component.css'
})
export class LedgerentryComponent {
  

}
