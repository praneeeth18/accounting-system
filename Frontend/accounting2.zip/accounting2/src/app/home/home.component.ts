import { Component } from '@angular/core';
@Component({
 selector: 'app-home',
 templateUrl: './home.component.html',
 styleUrls: ['./home.component.css']
})
export class HomeComponent {
 isSignInFormVisible: boolean = false;
 heading="Empowering Your Financial Journey"
 imgPath="../assets/image/img3.jpeg"
 heading1="Simplify, Analyze, Thrive!"
 toggleSignInForm(): void {
   this.isSignInFormVisible = !this.isSignInFormVisible;
 }
}