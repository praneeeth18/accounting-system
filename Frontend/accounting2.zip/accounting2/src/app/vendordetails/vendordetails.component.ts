import { Component } from '@angular/core';

@Component({
  selector: 'app-vendordetails',
  templateUrl: './vendordetails.component.html',
  styleUrl: './vendordetails.component.css'
})
export class VendordetailsComponent {

}
