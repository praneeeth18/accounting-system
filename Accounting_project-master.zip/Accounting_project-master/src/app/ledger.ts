export class Ledger {
    entryid:number=0;
    companyid:number=0;
    description:String='';
    debit:number=0;
    credit:number=0
}
